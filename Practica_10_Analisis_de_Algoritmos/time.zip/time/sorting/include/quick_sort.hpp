
#pragma once

#include <cstddef>

namespace ALGORITMIA
{
    void quick_sort(int *v, size_t sz, size_t &n_comp, size_t &n_swap);
}